/*
       CREATED BY SOUND GOD

  LARANGAN
 
- DONT SELL THIS SCRIPT

DONT FORGET TO SUPPORT AND SUBSCRIBE!
www.youtube.com/@mtg0dd
Youtube : Sound God
Telegram : t.me/soundgodd


*/

global.prefa = ['','!','.',',','🐤','🗿'] 
// Setting Contact
global.namaown = "Sound God"
global.namabot = "Sound God v1"
global.versisc = " 1.0"
global.owner = ["6285608652644"]
global.tele = "https://wa.me/6285608652644"
global.url = "https://www.youtube.com/@mtg0dd"
global.namastore = "Sound Gods"

// Global Simbol
global.simbol = "𓉸"
global.wlcm = []
global.wlcmm = []
global.limitawal = {
    premium: "Infinity",
    free: 20
}

// Global Respon
global.mess = {
    success: '𝗗𝗼𝗻𝗲 𝗕𝗿𝗼',
    admin: `\`[ # ]\` Perintah Ini Hanya Bisa Digunakan Oleh Admin Group !`,
    botAdmin: `\`[ # ]\` Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !`,
    OnlyOwner: `\`[ # ]\` Perintah Ini Hanya Bisa Digunakan Oleh Owner !`,
    OnlyGrup: `\`[ # ]\` Perintah Ini Hanya Bisa Digunakan Di Group Chat !`,
    private: `\`[ # ]\` Perintah Ini Hanya Bisa Digunakan Di Private Chat !`,
    wait: `\`[ # ]\` Wait Tunggu Sebentar`,
    notregist: `\`[ # ]\` Kamu Belum Terdaftar Di Database Bot Silahkan Daftar Terlebih Dahulu`,
    premium: `\`[ # ]\` khusus Murbug" Mau Join? Chat Owner`,
    endLimit: `\`[ # ]\` Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Pukul 00:00 WIB`,
     bugrespon: `\`[ # ]\` 𝙎𝙊𝙐𝙉𝘿𝑮𝑶𝑫
     ek bag post kar raha hai`,
     donebug: `\`[ # ]\` 𝗦𝘂𝗰𝗰𝗲𝘀𝗳𝘂𝗹𝗹𝘆 𝗦𝗲𝗻𝗱 𝗕𝘂𝗴
     Berashi ho gaya ha `,
}


// Batas Setting
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})